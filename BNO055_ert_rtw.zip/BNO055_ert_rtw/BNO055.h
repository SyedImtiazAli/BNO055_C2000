/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: BNO055.h
 *
 * Code generated for Simulink model 'BNO055'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jan 20 22:58:48 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BNO055_h_
#define RTW_HEADER_BNO055_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef BNO055_COMMON_INCLUDES_
#define BNO055_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "dt_info.h"
#include "ext_work.h"
#include "c2000BoardSupport.h"
#include "F2837xD_device.h"
#endif                                 /* BNO055_COMMON_INCLUDES_ */

#include "BNO055_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

extern void configureIXbar(void);
extern void init_I2C_GPIO(void);
extern void init_I2C_A(void);

/* Block signals (default storage) */
typedef struct {
  real32_T MemoryCopy;                 /* '<S5>/Memory Copy' */
  real32_T MemoryCopy1;                /* '<S5>/Memory Copy1' */
} B_BNO055_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay1_DSTATE;            /* '<Root>/Unit Delay1' */
  int16_T EnabledSubsystem2_SubsysRanBC;/* '<Root>/Enabled Subsystem2' */
  int16_T FunctionCallSubsystem_SubsysRan;/* '<S2>/Function-Call Subsystem' */
  int16_T FunctionCallSubsystem1_SubsysRa;/* '<S2>/Function-Call Subsystem1' */
  int16_T EnabledSubsystem_SubsysRanBC;/* '<Root>/Enabled Subsystem' */
  int16_T FunctionCallSubsystem_SubsysR_c;/* '<S1>/Function-Call Subsystem' */
  int16_T FunctionCallSubsystem1_Subsys_p;/* '<S1>/Function-Call Subsystem1' */
} DW_BNO055_T;

/* Parameters (default storage) */
struct P_BNO055_T_ {
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<Root>/Unit Delay1'
                                        */
  real_T Constant5_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant5'
                                        */
  real32_T Out1_Y0;                    /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S5>/Out1'
                                        */
  real32_T Out2_Y0;                    /* Computed Parameter: Out2_Y0
                                        * Referenced by: '<S5>/Out2'
                                        */
  uint16_T Constant2_Value;            /* Computed Parameter: Constant2_Value
                                        * Referenced by: '<S4>/Constant2'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_BNO055_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_BNO055_T BNO055_P;

/* Block signals (default storage) */
extern B_BNO055_T BNO055_B;

/* Block states (default storage) */
extern DW_BNO055_T BNO055_DW;

/* External function called from main */
extern void BNO055_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void BNO055_SetEventsForThisBaseStep(boolean_T *eventFlags);
extern void BNO055_initialize(void);
extern void BNO055_step0(void);
extern void BNO055_step1(void);
extern void BNO055_terminate(void);

/* Real-time Model object */
extern RT_MODEL_BNO055_T *const BNO055_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'BNO055'
 * '<S1>'   : 'BNO055/Enabled Subsystem'
 * '<S2>'   : 'BNO055/Enabled Subsystem2'
 * '<S3>'   : 'BNO055/Enabled Subsystem/Function-Call Subsystem'
 * '<S4>'   : 'BNO055/Enabled Subsystem/Function-Call Subsystem1'
 * '<S5>'   : 'BNO055/Enabled Subsystem2/Function-Call Subsystem'
 * '<S6>'   : 'BNO055/Enabled Subsystem2/Function-Call Subsystem1'
 */

/* user code (bottom of header file) */
/* System '<Root>' */
extern uint8_T i;
extern uint8_T data[24];
extern uint8_T High_byte;
extern uint8_T Low_byte;
extern float Yaw;
extern float Yaw_rate;

#endif                                 /* RTW_HEADER_BNO055_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
