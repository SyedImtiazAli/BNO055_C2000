/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: BNO055_data.c
 *
 * Code generated for Simulink model 'BNO055'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jan 20 22:58:48 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BNO055.h"
#include "BNO055_private.h"

/* Block parameters (default storage) */
P_BNO055_T BNO055_P = {
  /* Expression: 0
   * Referenced by: '<Root>/Unit Delay1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant5'
   */
  1.0,

  /* Computed Parameter: Out1_Y0
   * Referenced by: '<S5>/Out1'
   */
  0.0F,

  /* Computed Parameter: Out2_Y0
   * Referenced by: '<S5>/Out2'
   */
  0.0F,

  /* Computed Parameter: Constant2_Value
   * Referenced by: '<S4>/Constant2'
   */
  0U
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
