/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: BNO055.c
 *
 * Code generated for Simulink model 'BNO055'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jan 20 22:58:48 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BNO055.h"
#include "BNO055_private.h"
#include "BNO055_dt.h"

/* user code (top of source file) */
/* System '<Root>' */
#define BNO055_ADDR                    40
#define BNO055_EULER                   26
#define BNO055_Gyro_z                  24

uint8_T data[24] = { 0x3D, 0x00, 0x07, 0x01, 0x08, 0x1F, 0x0A, 0x00, 0x0B, 0x00,
  0x09, 0x1F, 0x07, 0x00, 0x40, 0x01, 0x3B, 0x01, 0x3E, 0x00, 0x3D, 12, 0x07,
  0x00 };

uint8_T i = 0;
uint8_T High_byte = 0;
uint8_T Low_byte = 0;
float Yaw = 0;
float Yaw_rate = 0;

/* Block signals (default storage) */
B_BNO055_T BNO055_B;

/* Block states (default storage) */
DW_BNO055_T BNO055_DW;

/* Real-time model */
static RT_MODEL_BNO055_T BNO055_M_;
RT_MODEL_BNO055_T *const BNO055_M = &BNO055_M_;
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void BNO055_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(BNO055_M, 1));
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (BNO055_M->Timing.TaskCounters.TID[1])++;
  if ((BNO055_M->Timing.TaskCounters.TID[1]) > 4) {/* Sample time: [0.05s, 0.0s] */
    BNO055_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* Model step function for TID0 */
void BNO055_step0(void)                /* Sample time: [0.01s, 0.0s] */
{
  {                                    /* Sample time: [0.01s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* External mode */
  rtExtModeUploadCheckTrigger(2);
  rtExtModeUpload(0, (real_T)BNO055_M->Timing.taskTime0);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.01s, 0.0s] */
    if ((rtmGetTFinal(BNO055_M)!=-1) &&
        !((rtmGetTFinal(BNO055_M)-BNO055_M->Timing.taskTime0) >
          BNO055_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(BNO055_M, "Simulation finished");
    }

    if (rtmGetStopRequested(BNO055_M)) {
      rtmSetErrorStatus(BNO055_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  BNO055_M->Timing.taskTime0 =
    ((time_T)(++BNO055_M->Timing.clockTick0)) * BNO055_M->Timing.stepSize0;
}

/* Model step function for TID1 */
void BNO055_step1(void)                /* Sample time: [0.05s, 0.0s] */
{
  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.FunctionCallSubsystem1_Subsys_p);

  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.FunctionCallSubsystem_SubsysR_c);

  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.EnabledSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.FunctionCallSubsystem1_SubsysRa);

  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.FunctionCallSubsystem_SubsysRan);

  /* Reset subsysRan breadcrumbs */
  srClearBC(BNO055_DW.EnabledSubsystem2_SubsysRanBC);

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem2' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  /* UnitDelay: '<Root>/Unit Delay1' */
  if (BNO055_DW.UnitDelay1_DSTATE > 0.0) {
    /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/Function-Call Subsystem1'
     */

    /* user code (Output function Body) */

    /* System '<S2>/Function-Call Subsystem1' */
    while (I2caRegs.I2CSTR.bit.BB == 1) ;
                                      // busy loop (receive or send a start bit)
    I2caRegs.I2CSTR.bit.SCD = 1;       // Clear the SCD bit (stop condition bit)
    while (I2caRegs.I2CMDR.bit.STP == 1) ;// make sure the i2c bus has stopped
    I2caRegs.I2CCNT= 1;                /* Set data length */
    I2caRegs.I2CFFTX.bit.TXFFIL = 1;
    I2caRegs.I2CMDR.all = 28192;
    I2caRegs.I2CDXR.bit.DATA = BNO055_Gyro_z;
    while (I2caRegs.I2CMDR.bit.STP == 1) ;
    I2caRegs.I2CFFTX.bit.TXFFINTCLR = 1;
    while (I2caRegs.I2CSTR.bit.BB == 1) ;
                                      // busy loop (receive or send a start bit)
    I2caRegs.I2CSTR.bit.SCD = 1;       // Clear the SCD bit (stop condition bit)
    while (I2caRegs.I2CMDR.bit.STP == 1) ;// make sure the i2c bus has stopped
    I2caRegs.I2CCNT= 2;                /* Set data length */
    I2caRegs.I2CMDR.all = 27680;
    Low_byte = I2caRegs.I2CDRR.bit.DATA;
    High_byte = I2caRegs.I2CDRR.bit.DATA;
    Yaw_rate = (int16_T)High_byte << 8 | (int16_T)Low_byte;
    Yaw_rate = Yaw_rate/16;
    High_byte = 0;
    Low_byte = 0;
    while (I2caRegs.I2CSTR.bit.BB == 1) ;
                                      // busy loop (receive or send a start bit)
    I2caRegs.I2CSTR.bit.SCD = 1;       // Clear the SCD bit (stop condition bit)
    while (I2caRegs.I2CMDR.bit.STP == 1) ;// make sure the i2c bus has stopped
    I2caRegs.I2CCNT= 1;                /* Set data length */
    I2caRegs.I2CFFTX.bit.TXFFIL = 1;
    I2caRegs.I2CMDR.all = 28192;
    I2caRegs.I2CDXR.bit.DATA = BNO055_EULER;
    while (I2caRegs.I2CMDR.bit.STP == 1) ;
    I2caRegs.I2CFFTX.bit.TXFFINTCLR = 1;
    DELAY_US(10);
    while (I2caRegs.I2CSTR.bit.BB == 1) ;
                                      // busy loop (receive or send a start bit)
    I2caRegs.I2CSTR.bit.SCD = 1;       // Clear the SCD bit (stop condition bit)
    while (I2caRegs.I2CMDR.bit.STP == 1) ;// make sure the i2c bus has stopped
    I2caRegs.I2CCNT= 2;                /* Set data length */
    I2caRegs.I2CMDR.all = 27680;
    Low_byte = I2caRegs.I2CDRR.bit.DATA;
    High_byte = I2caRegs.I2CDRR.bit.DATA;
    Yaw = (int16_T)High_byte << 8 | (int16_T)Low_byte;
    Yaw = Yaw/16;
    DELAY_US(10);
    BNO055_DW.FunctionCallSubsystem1_SubsysRa = 4;

    /* S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
     *  SubSystem: '<S2>/Function-Call Subsystem'
     */
    /* S-Function (memorycopy): '<S5>/Memory Copy' */
    {
      real32_T *memindsrc = (real32_T *) (&Yaw_rate);
      real32_T *meminddst = (real32_T *) (&BNO055_B.MemoryCopy);
      *(real32_T *) (meminddst) = *(real32_T *) (memindsrc);
    }

    /* S-Function (memorycopy): '<S5>/Memory Copy1' */
    {
      real32_T *memindsrc = (real32_T *) (&Yaw);
      real32_T *meminddst = (real32_T *) (&BNO055_B.MemoryCopy1);
      *(real32_T *) (meminddst) = *(real32_T *) (memindsrc);
    }

    BNO055_DW.FunctionCallSubsystem_SubsysRan = 4;

    /* End of Outputs for S-Function (fcgen): '<S2>/Function-Call Generator' */
    srUpdateBC(BNO055_DW.EnabledSubsystem2_SubsysRanBC);
  }

  /* End of UnitDelay: '<Root>/Unit Delay1' */
  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem2' */

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S1>/Enable'
   */
  /* Logic: '<Root>/NOT1' */
  if (!(BNO055_DW.UnitDelay1_DSTATE != 0.0)) {
    /* S-Function (fcgen): '<S1>/Function-Call Generator' incorporates:
     *  SubSystem: '<S1>/Function-Call Subsystem1'
     */

    /* S-Function (c280xi2c_tx): '<S4>/I2C Transmit' incorporates:
     *  Constant: '<S4>/Constant2'
     */
    {
      int unsigned tx_loop= 0;
      while (I2caRegs.I2CFFTX.bit.TXFFST!=0 && tx_loop<10000 )
        tx_loop++;
      if (tx_loop!=10000) {
        I2caRegs.I2CCNT= 1;            /* Set data length */

        /* mode:1 (1:master 0:slave)  Addressing mode:0 (1:10-bit 0:7-bit)
           free data mode:1 (1:enbaled 0:disabled) digital loopback mode:0 (1:enabled 0:disabled)
           bit count:0 (0:8bit) stop condition:1 (1:enabled 0: disabled)*/
        I2caRegs.I2CMDR.all = 28200;
        tx_loop= 0;
        while (I2caRegs.I2CFFTX.bit.TXFFST==16 && tx_loop<10000)
          tx_loop++;
        if (tx_loop!=10000) {
          I2caRegs.I2CDXR.bit.DATA = (uint8_T)BNO055_P.Constant2_Value;
        }
      }
    }

    /* user code (Output function Trailer) */

    /* System '<S1>/Function-Call Subsystem1' */
    I2caRegs.I2CMDR.bit.STP = 0;
    I2caRegs.I2CMDR.bit.IRS = 0;
    I2caRegs.I2CMDR.bit.IRS = 1;
    BNO055_DW.FunctionCallSubsystem1_Subsys_p = 4;

    /* S-Function (fcgen): '<S1>/Function-Call Generator' incorporates:
     *  SubSystem: '<S1>/Function-Call Subsystem'
     */

    /* user code (Output function Body) */

    /* System '<S1>/Function-Call Subsystem' */
    while (i < 24) {
      while (I2caRegs.I2CSTR.bit.BB == 1) ;
                                      // busy loop (receive or send a start bit)
      I2caRegs.I2CSTR.bit.SCD = 1;     // Clear the SCD bit (stop condition bit)
      while (I2caRegs.I2CMDR.bit.STP == 1) ;// make sure the i2c bus has stopped
      I2caRegs.I2CSAR.bit.SAR = BNO055_ADDR;/* Set slave address*/
      I2caRegs.I2CCNT= 2;              /* Set data length */
      I2caRegs.I2CFFTX.bit.TXFFIL = 2;
      I2caRegs.I2CMDR.all = 28192;
      I2caRegs.I2CDXR.bit.DATA = data[i];
      I2caRegs.I2CDXR.bit.DATA = data[i+1];
      i = i + 2;
      while (I2caRegs.I2CMDR.bit.STP == 1) ;
      I2caRegs.I2CFFTX.bit.TXFFINTCLR = 1;
      DELAY_US(500);
    }

    BNO055_DW.FunctionCallSubsystem_SubsysR_c = 4;

    /* End of Outputs for S-Function (fcgen): '<S1>/Function-Call Generator' */
    srUpdateBC(BNO055_DW.EnabledSubsystem_SubsysRanBC);
  }

  /* End of Logic: '<Root>/NOT1' */
  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */

  /* Update for UnitDelay: '<Root>/Unit Delay1' incorporates:
   *  Constant: '<Root>/Constant5'
   */
  BNO055_DW.UnitDelay1_DSTATE = BNO055_P.Constant5_Value;
  rtExtModeUpload(1, (real_T)((BNO055_M->Timing.clockTick1) * 0.05));

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.05, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   */
  BNO055_M->Timing.clockTick1++;
}

/* Model initialize function */
void BNO055_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)BNO055_M, 0,
                sizeof(RT_MODEL_BNO055_T));
  rtmSetTFinal(BNO055_M, -1);
  BNO055_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  BNO055_M->Sizes.checksums[0] = (3618059495U);
  BNO055_M->Sizes.checksums[1] = (3610882492U);
  BNO055_M->Sizes.checksums[2] = (3568500441U);
  BNO055_M->Sizes.checksums[3] = (3411943155U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[7];
    BNO055_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&BNO055_DW.FunctionCallSubsystem_SubsysR_c;
    systemRan[2] = (sysRanDType *)&BNO055_DW.FunctionCallSubsystem1_Subsys_p;
    systemRan[3] = (sysRanDType *)&BNO055_DW.EnabledSubsystem_SubsysRanBC;
    systemRan[4] = (sysRanDType *)&BNO055_DW.FunctionCallSubsystem_SubsysRan;
    systemRan[5] = (sysRanDType *)&BNO055_DW.FunctionCallSubsystem1_SubsysRa;
    systemRan[6] = (sysRanDType *)&BNO055_DW.EnabledSubsystem2_SubsysRanBC;
    rteiSetModelMappingInfoPtr(BNO055_M->extModeInfo,
      &BNO055_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(BNO055_M->extModeInfo, BNO055_M->Sizes.checksums);
    rteiSetTPtr(BNO055_M->extModeInfo, rtmGetTPtr(BNO055_M));
  }

  /* block I/O */
  (void) memset(((void *) &BNO055_B), 0,
                sizeof(B_BNO055_T));

  /* states (dwork) */
  (void) memset((void *)&BNO055_DW, 0,
                sizeof(DW_BNO055_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    BNO055_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 20;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* InitializeConditions for UnitDelay: '<Root>/Unit Delay1' */
  BNO055_DW.UnitDelay1_DSTATE = BNO055_P.UnitDelay1_InitialCondition;

  /* SystemInitialize for S-Function (fcgen): '<S1>/Function-Call Generator' incorporates:
   *  SubSystem: '<S1>/Function-Call Subsystem1'
   */

  /* SystemInitialize for Enabled SubSystem: '<Root>/Enabled Subsystem2' */
  /* SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
   *  SubSystem: '<S2>/Function-Call Subsystem1'
   */

  /* SystemInitialize for S-Function (memorycopy): '<S5>/Memory Copy' incorporates:
   *  Outport: '<S5>/Out1'
   */
  BNO055_B.MemoryCopy = BNO055_P.Out1_Y0;

  /* SystemInitialize for S-Function (memorycopy): '<S5>/Memory Copy1' incorporates:
   *  Outport: '<S5>/Out2'
   */
  BNO055_B.MemoryCopy1 = BNO055_P.Out2_Y0;

  /* End of SystemInitialize for S-Function (fcgen): '<S2>/Function-Call Generator' */
  /* End of SystemInitialize for SubSystem: '<Root>/Enabled Subsystem2' */
}

/* Model terminate function */
void BNO055_terminate(void)
{
  /* Terminate for Enabled SubSystem: '<Root>/Enabled Subsystem2' */
  /* Terminate for S-Function (fcgen): '<S2>/Function-Call Generator' incorporates:
   *  SubSystem: '<S2>/Function-Call Subsystem1'
   */

  /* Terminate for S-Function (fcgen): '<S1>/Function-Call Generator' incorporates:
   *  SubSystem: '<S1>/Function-Call Subsystem1'
   */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
