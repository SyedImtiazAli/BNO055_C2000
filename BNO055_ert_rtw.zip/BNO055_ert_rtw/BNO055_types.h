/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: BNO055_types.h
 *
 * Code generated for Simulink model 'BNO055'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jan 20 22:58:48 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BNO055_types_h_
#define RTW_HEADER_BNO055_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_BNO055_T_ P_BNO055_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_BNO055_T RT_MODEL_BNO055_T;

#endif                                 /* RTW_HEADER_BNO055_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
